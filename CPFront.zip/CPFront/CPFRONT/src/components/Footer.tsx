export default function Footer(){
  return (
    <footer className="footer">
      <div className="inner">Desenvolvido por Fulano - RA: 0000000 © 2024</div>
    </footer>
  );
}
